const SERVER_IP = 'mc.startimex.ru';
const API_URL = `https://api.mcsrvstat.us/3/${SERVER_IP}`;

/* ===== SNOW ===== */
function createSnow() {
    const container = document.createElement('div');
    container.className = 'snow-container';
    document.body.appendChild(container);
    const count = window.innerWidth < 768 ? 35 : 60;
    for (let i = 0; i < count; i++) {
        const flake = document.createElement('div');
        flake.className = 'snowflake';
        const size = Math.random() * 4 + 2;
        flake.style.width = size + 'px';
        flake.style.height = size + 'px';
        flake.style.left = Math.random() * 100 + '%';
        flake.style.animationDuration = (Math.random() * 8 + 6) + 's';
        flake.style.animationDelay = (Math.random() * 8) + 's';
        flake.style.opacity = Math.random() * 0.5 + 0.3;
        container.appendChild(flake);
    }
}

/* ===== SERVER STATUS ===== */
async function fetchServerStatus() {
    try {
        const res = await fetch(API_URL);
        const data = await res.json();
        updateUI(data);
    } catch (err) {
        console.error('Ошибка:', err);
        setOffline();
    }
}

function updateUI(data) {
    const isOnline = data.online === true;
    const players = data.players?.online ?? 0;
    const max = data.players?.max ?? '?';
    const version = data.version || '—';
    const motd = data.motd?.clean?.join(' ') || data.motd?.raw?.join(' ') || '';

    const navDot = document.querySelector('#nav-status .status-dot');
    const navOnline = document.getElementById('nav-online');
    if (navDot && navOnline) {
        navDot.className = 'status-dot ' + (isOnline ? 'online' : 'offline');
        navOnline.textContent = isOnline ? `${players} онлайн` : 'Оффлайн';
    }

    const onlineCount = document.getElementById('online-count');
    const onlineMax = document.getElementById('online-max');
    if (onlineCount) {
        onlineCount.textContent = isOnline ? players : '0';
        if (onlineMax) onlineMax.textContent = isOnline ? `из ${max}` : 'Сервер оффлайн';
    }

    const analyticsOnline = document.getElementById('analytics-online');
    const analyticsMax = document.getElementById('analytics-max');
    const statusBadge = document.getElementById('server-status-badge');
    const versionEl = document.getElementById('server-version');
    const onlineStatusEl = document.getElementById('server-online-status');
    const motdEl = document.getElementById('server-motd');

    if (analyticsOnline) {
        analyticsOnline.textContent = isOnline ? players : '0';
        if (analyticsMax) analyticsMax.textContent = max;
    }
    if (statusBadge) {
        statusBadge.textContent = isOnline ? 'Онлайн' : 'Оффлайн';
        statusBadge.className = 'status-badge ' + (isOnline ? 'online' : 'offline');
    }
    if (versionEl) versionEl.textContent = version;
    if (onlineStatusEl) onlineStatusEl.textContent = isOnline ? 'Онлайн' : 'Оффлайн';
    if (motdEl && motd) motdEl.textContent = motd;
}

function setOffline() {
    const navDot = document.querySelector('#nav-status .status-dot');
    const navOnline = document.getElementById('nav-online');
    if (navDot) navDot.className = 'status-dot offline';
    if (navOnline) navOnline.textContent = 'Ошибка';
    const onlineCount = document.getElementById('online-count');
    if (onlineCount) onlineCount.textContent = '—';
}

function copyIP() {
    navigator.clipboard.writeText(SERVER_IP).then(() => {
        document.querySelectorAll('.copy-btn').forEach(btn => {
            const original = btn.innerHTML;
            btn.innerHTML = '✓';
            btn.style.color = '#34d399';
            setTimeout(() => { btn.innerHTML = original; btn.style.color = ''; }, 1500);
        });
    });
}

/* ===== INTERACTIVE CHART ===== */
let chartData = { points: [], labels: [], period: '24h' };
let chartMetrics = null;

function drawChart(period = '24h') {
    const canvas = document.getElementById('onlineChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = 280 * dpr;
    ctx.scale(dpr, dpr);
    const w = rect.width;
    const h = 280;

    ctx.clearRect(0, 0, w, h);

    let points = [];
    let labels = [];
    if (period === '24h') {
        for (let i = 0; i < 24; i++) {
            points.push(0);
            labels.push(String(i).padStart(2, '0') + ':00');
        }
    } else if (period === '7d') {
        const days = ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс'];
        // approximate labels like in video
        const dayNames = ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс'];
        for (let i = 0; i < 7; i++) {
            points.push(0);
            labels.push(dayNames[i]);
        }
    } else {
        for (let i = 0; i < 30; i++) {
            points.push(0);
            labels.push((i + 1) + ' окт');
        }
    }

    chartData = { points, labels, period };

    const maxY = 1;
    const padding = { top: 30, right: 20, bottom: 40, left: 45 };
    const chartW = w - padding.left - padding.right;
    const chartH = h - padding.top - padding.bottom;
    const y0 = padding.top + chartH;

    chartMetrics = { padding, chartW, chartH, y0, w, h, maxY };

    // Grid
    ctx.strokeStyle = 'rgba(167, 139, 250, 0.12)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 5; i++) {
        const y = padding.top + (chartH / 5) * i;
        ctx.beginPath();
        ctx.moveTo(padding.left, y);
        ctx.lineTo(w - padding.right, y);
        ctx.stroke();
        ctx.fillStyle = 'rgba(196, 181, 253, 0.55)';
        ctx.font = '12px Inter, sans-serif';
        ctx.fillText((maxY - (maxY / 5) * i).toFixed(1), 8, y + 4);
    }

    // Green zero line
    ctx.beginPath();
    ctx.strokeStyle = '#34d399';
    ctx.lineWidth = 2.5;
    points.forEach((_, i) => {
        const x = padding.left + (chartW / (points.length - 1 || 1)) * i;
        if (i === 0) ctx.moveTo(x, y0);
        else ctx.lineTo(x, y0);
    });
    ctx.stroke();

    // Glow
    ctx.beginPath();
    ctx.moveTo(padding.left, y0);
    ctx.lineTo(padding.left + chartW, y0);
    ctx.lineTo(padding.left + chartW, y0 + 8);
    ctx.lineTo(padding.left, y0 + 8);
    ctx.closePath();
    const grad = ctx.createLinearGradient(0, y0, 0, y0 + 12);
    grad.addColorStop(0, 'rgba(52, 211, 153, 0.25)');
    grad.addColorStop(1, 'rgba(52, 211, 153, 0)');
    ctx.fillStyle = grad;
    ctx.fill();

    // Dots
    points.forEach((_, i) => {
        const x = padding.left + (chartW / (points.length - 1 || 1)) * i;
        ctx.beginPath();
        ctx.arc(x, y0, 3.5, 0, Math.PI * 2);
        ctx.fillStyle = '#34d399';
        ctx.fill();
    });

    // X labels
    ctx.fillStyle = 'rgba(196, 181, 253, 0.65)';
    ctx.font = '11px Inter, sans-serif';
    const step = Math.ceil(labels.length / 7);
    labels.forEach((lab, i) => {
        if (i % step === 0 || i === labels.length - 1) {
            const x = padding.left + (chartW / (points.length - 1 || 1)) * i;
            ctx.fillText(lab, x - 12, h - 12);
        }
    });

    const titleEl = document.getElementById('chart-title');
    if (titleEl) {
        const t = period === '24h' ? 'за 24 часа' : period === '7d' ? 'за 7 дней' : 'за 30 дней';
        titleEl.textContent = `mc.startimex.ru онлайн ${t}`;
    }
}

function showTooltip(e) {
    const canvas = document.getElementById('onlineChart');
    const tooltip = document.getElementById('chartTooltip');
    if (!canvas || !tooltip || !chartMetrics || !chartData.points.length) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX || e.touches?.[0]?.clientX) - rect.left;
    const { padding, chartW } = chartMetrics;
    const n = chartData.points.length;

    if (x < padding.left || x > padding.left + chartW) {
        tooltip.style.display = 'none';
        return;
    }

    const idx = Math.round(((x - padding.left) / chartW) * (n - 1));
    const clamped = Math.max(0, Math.min(n - 1, idx));
    const label = chartData.labels[clamped];
    const val = chartData.points[clamped];

    tooltip.innerHTML = `<strong>${label}</strong><br><span style="color:#34d399">■</span> ${val} игроков`;
    tooltip.style.display = 'block';

    const tipX = (e.clientX || e.touches?.[0]?.clientX) - rect.left;
    const tipY = (e.clientY || e.touches?.[0]?.clientY) - rect.top;
    tooltip.style.left = Math.min(tipX + 12, rect.width - 120) + 'px';
    tooltip.style.top = Math.max(tipY - 50, 8) + 'px';
}

function hideTooltip() {
    const tooltip = document.getElementById('chartTooltip');
    if (tooltip) tooltip.style.display = 'none';
}

function initChartTabs() {
    document.querySelectorAll('.chart-tabs .tab').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.chart-tabs .tab').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            drawChart(btn.dataset.period);
        });
    });

    const canvas = document.getElementById('onlineChart');
    if (canvas) {
        canvas.addEventListener('mousemove', showTooltip);
        canvas.addEventListener('mouseleave', hideTooltip);
        canvas.addEventListener('click', showTooltip);
        canvas.addEventListener('touchstart', showTooltip, { passive: true });
        canvas.addEventListener('touchmove', showTooltip, { passive: true });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    createSnow();
    fetchServerStatus();
    setInterval(fetchServerStatus, 60000);

    if (document.getElementById('onlineChart')) {
        initChartTabs();
        drawChart('24h');
        window.addEventListener('resize', () => {
            const active = document.querySelector('.tab.active');
            drawChart(active?.dataset.period || '24h');
        });
    }
});
